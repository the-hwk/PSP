create
    definer = root@localhost procedure SelectPasswordByUser(IN userId int)
begin
	select * from passwords where passwords.userId = userId;
end;

