create
    definer = root@localhost procedure SelectRoomById(IN id int)
begin
	select * from rooms where rooms.id = id;
end;

