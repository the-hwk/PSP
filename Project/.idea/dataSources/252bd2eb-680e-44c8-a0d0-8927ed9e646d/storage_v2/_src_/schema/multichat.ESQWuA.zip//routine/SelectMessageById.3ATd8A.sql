create
    definer = root@localhost procedure SelectMessageById(IN id int)
begin
	select * from messages where messages.id = id;
end;

