create
    definer = root@localhost procedure InsertPassword(IN userId int, IN value blob)
begin
	insert passwords (userId, value) values (userId, value);
    select id from passwords order by id desc limit 1;
end;

