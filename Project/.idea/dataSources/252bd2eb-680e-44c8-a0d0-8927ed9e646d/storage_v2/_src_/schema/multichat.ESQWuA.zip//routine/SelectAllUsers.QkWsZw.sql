create
    definer = root@localhost procedure SelectAllUsers()
begin
	select * from users;
end;

