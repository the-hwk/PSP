create
    definer = root@localhost procedure SelectRoomsByUser(IN userId int)
begin
	select rooms.id, rooms.name from rooms_data join rooms on rooms.id = rooms_data.roomId 
		join users on users.id = rooms_data.userId where rooms_data.userId = userId;
end;

