create
    definer = root@localhost procedure InsertUser(IN email varchar(30), IN nickname varchar(30), IN roleId int)
begin
	insert users (email, nickname, roleId) values (email, nickname, roleId);
    select id from usersdata order by id desc limit 1;
end;

