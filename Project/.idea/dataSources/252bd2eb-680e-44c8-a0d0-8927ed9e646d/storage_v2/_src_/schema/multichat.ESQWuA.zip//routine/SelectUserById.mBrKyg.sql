create
    definer = root@localhost procedure SelectUserById(IN id int)
begin
	select * from users where users.id = id;
end;

