create
    definer = root@localhost procedure InsertRoom(IN name varchar(30))
begin
	insert rooms (name) values (name);
    select id from rooms order by id desc limit 1;
end;

