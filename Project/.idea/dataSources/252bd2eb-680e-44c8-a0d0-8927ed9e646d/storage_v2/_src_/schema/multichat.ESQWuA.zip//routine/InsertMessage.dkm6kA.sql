create
    definer = root@localhost procedure InsertMessage(IN value varchar(300), IN userId int, IN roomId int)
begin
	insert messages(value, userId, roomId) values (value, userId, roomId);
    select id from messages order by id desc limit 1;
end;

