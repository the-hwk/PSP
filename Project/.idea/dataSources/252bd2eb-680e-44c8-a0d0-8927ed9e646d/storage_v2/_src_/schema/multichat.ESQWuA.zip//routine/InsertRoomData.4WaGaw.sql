create
    definer = root@localhost procedure InsertRoomData(IN roomId int, IN userId int)
begin
	insert rooms_data(userId, roomId) values (userId, roomId);
    select id from rooms_data order by id desc limit 1;
end;

