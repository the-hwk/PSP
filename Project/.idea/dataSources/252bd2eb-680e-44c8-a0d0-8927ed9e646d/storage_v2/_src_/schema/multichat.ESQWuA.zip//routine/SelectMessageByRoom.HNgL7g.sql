create
    definer = root@localhost procedure SelectMessageByRoom(IN roomId int)
begin
	select * from messages where messages.roomId = roomId;
end;

